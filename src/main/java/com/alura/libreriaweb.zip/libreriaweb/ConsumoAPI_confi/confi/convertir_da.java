package com.alura.libreriaweb.ConsumoAPI_confi.confi;

public interface convertir_da {
    <T> T convertirDatosJsonAJava(String json, Class<T> clase );
}
