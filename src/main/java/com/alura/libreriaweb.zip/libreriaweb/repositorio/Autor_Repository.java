package com.alura.libreriaweb.repositorio;
import com.alura.libreriaweb.Items.Autor;
import java.util.List;
import java.util.Optional;

public interface Autor_Repository {
    List<Autor> findAll();


    List<Autor> findByCumpleaniosLessThanOrFechaFallecimientoGreaterThanEqual(int anioBuscado, int anioBuscado1);

    Optional<Autor> findFirstByNombreContainsIgnoreCase(String escritor);
}
